#include <stdio.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>


#define TLB_SIZE 16
#define PAGES 256
#define PAGE_SIZE 256
#define OFFSET_BITS 8
#define OFFSET_MASK 255
#define MEMORY_SIZE (PAGES * PAGE_SIZE)
#define BUFFER_SIZE 10

struct tlbentry {
    unsigned char logical;
    unsigned char physical;
};

struct tlbentry tlb[TLB_SIZE];
int tlbindex = 0;
int pagetable[PAGES];
signed char main_memory[MEMORY_SIZE];
signed char* backing;

int main(int argc, const char* argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: ./virtmem backingstore input\n");
        exit(1);
    }

    const char* backing_filename = argv[1];
    int backing_fd = open(backing_filename, O_RDONLY);
    backing = mmap(0, MEMORY_SIZE, PROT_READ, MAP_PRIVATE, backing_fd, 0);
    
    const char* input_filename = argv[2];
    FILE* input_fp = fopen(input_filename, "r");
   

    for (int i = 0; i < PAGES; i++) {
        pagetable[i] = -1;
    }

    char buffer[BUFFER_SIZE];
    int total_addresses = 0, tlb_hits = 0, page_faults = 0;
    unsigned char free_page = 0;

    while (fgets(buffer, BUFFER_SIZE, input_fp)) {
        int logical_address = atoi(buffer);
        total_addresses++;

        int logical_page = (logical_address >> OFFSET_BITS) & 0xFF;
        int offset = logical_address & OFFSET_MASK;

        int physical_page = -1;
        int tlb_hit = 0;

        for (int i = 0; i < TLB_SIZE; i++) {   // Search TLB for matching logical page
            if (tlb[i].logical == logical_page) {
                physical_page = tlb[i].physical;
                tlb_hits++;
                tlb_hit = 1;
                break;
            }
        }

        if (!tlb_hit) {  // If not found in TLB, consult page table
            if (pagetable[logical_page] == -1) {
                page_faults++;                    // Page fault: load from backing store

                physical_page = free_page++;
                memcpy(main_memory + physical_page * PAGE_SIZE,
                    backing + logical_page * PAGE_SIZE,
                    PAGE_SIZE);
                pagetable[logical_page] = physical_page;
            }
            else { // Page is already in memory
                physical_page = pagetable[logical_page];
            }
            // Update TLB using FIFO replacement
            tlb[tlbindex % TLB_SIZE].logical = logical_page;
            tlb[tlbindex % TLB_SIZE].physical = physical_page;
            tlbindex++;
        }

        int physical_address = (physical_page << OFFSET_BITS) | offset; // Compute physical address and retrieve value
        signed char value = main_memory[physical_address];

        printf("Virtual address: %d Physical address: %d Value: %d\n",
            logical_address, physical_address, value);
    }

    printf("Number of Translated Addresses = %d\n", total_addresses);
    printf("Page Faults = %d\n", page_faults);
    printf("Page Fault Rate = %.3f\n", page_faults / (1. * total_addresses));
    printf("TLB Hits = %d\n", tlb_hits);
    printf("TLB Hit Rate = %.3f\n", tlb_hits / (1. * total_addresses));

    return 0;
}
